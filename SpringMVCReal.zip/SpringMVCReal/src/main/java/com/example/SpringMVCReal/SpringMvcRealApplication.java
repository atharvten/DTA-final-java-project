package com.example.SpringMVCReal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcRealApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcRealApplication.class, args);
	}

}
